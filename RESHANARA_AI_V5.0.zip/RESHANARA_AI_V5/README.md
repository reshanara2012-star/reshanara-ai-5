# RESHANARA AI — Version 5.0 (Android project)

Version 5.0 packages the RESHANARA AI web interface in an Android WebView app and adds a collection of practical tools.

## Version 5 additions

- Word and character counter
- Local quick notes
- Local task list
- Stopwatch
- Countdown timer
- JSON formatter and minifier
- Text case and whitespace transformer
- Length and weight converter
- Colour picker with HEX display
- Date difference calculator
- Tip and bill-splitting calculator

## Existing app tools

The project also retains the existing chat demo, media studio, WAV music creator, optional online MP3 export, animated WebM title-video creator, PDF print workflow, JPG canvas creator, code workshop, voice tools, file reader, and AI backend settings.

## Build an APK with GitHub Actions

1. Upload the contents of this ZIP to the root of a GitHub repository.
2. Open the repository's **Actions** tab.
3. Choose **Build RESHANARA AI APK**.
4. Press **Run workflow** and wait for the build to finish.
5. Open the completed run and download the `RESHANARA-AI-debug-APK` artifact.
6. Extract the artifact and install the APK on your Android device.

## Important limitations

- This ZIP contains Android source code, not a prebuilt APK. It has not been compiled or tested on a physical device in this environment.
- The chat uses demo replies until a compatible HTTPS backend is configured in AI Connection settings. No real AI model or API key is bundled.
- MP3 export loads an MP3 encoder from the internet; WAV creation is local.
- The title-video creator exports WebM where the browser supports MediaRecorder. It is not a full timeline editor or text-to-video model.
- Speech features depend on Android WebView and installed speech services.
- Notes and tasks use browser local storage on the device and are not automatically synced.
- Never put a private API key directly into the app or repository. Use a secure server-side backend.

## Android project details

- Application ID: `com.reshanara.ai`
- Version name: `5.0`
- Minimum Android: 6.0 (API 23)
- Compile SDK: 35
- Java: 17
