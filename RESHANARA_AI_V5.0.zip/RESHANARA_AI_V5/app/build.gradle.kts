plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.reshanara.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.reshanara.ai"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "5.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
